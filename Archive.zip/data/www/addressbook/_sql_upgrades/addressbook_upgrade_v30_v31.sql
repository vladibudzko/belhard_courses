ALTER TABLE `group_list` add column `group_footer` mediumtext NOT NULL;
