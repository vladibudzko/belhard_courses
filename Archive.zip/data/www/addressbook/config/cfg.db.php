<?php
$dbserver     = "db";
$dbname       = "test";
$dbuser       = "addressbook";
$dbpass       = "addressbook";
$table_prefix = "";
$keep_history = true;
?>